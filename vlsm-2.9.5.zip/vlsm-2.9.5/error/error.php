<?php
include("../header.php")
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
     <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
              <br>
              <br>
              <br>
              <br>
              <br>
              <h1 style="color:red;text-align: center;">Sorry! You are not allowed to access this page.<br/><small>Please contact the System Admin.</small></h1>
        </div>
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<?php
include("../footer.php")
?>