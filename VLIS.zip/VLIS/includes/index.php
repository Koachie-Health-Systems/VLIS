<?php

header("Location:/");

?>
